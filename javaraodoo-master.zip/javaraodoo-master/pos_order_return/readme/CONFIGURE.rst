In some cases, you may want to let the possibility to allow negative quantity
in a PoS Order, without mentioning initial order. This can happen for special
products like returnable products, etc.

In that case, a checkbox is possible on Product Form View to allow such case

.. image:: /pos_order_return/static/description/product_returnable_bottle.png

.. image:: https://odoo-community.org/website/image/ir.attachment/5784_f2813bd/datas
   :alt: Try me on Runbot
   :target: https://runbot.odoo-community.org/runbot/184/10.0
