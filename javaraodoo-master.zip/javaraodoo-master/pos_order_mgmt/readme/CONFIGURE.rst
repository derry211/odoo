To configure this module, you need to:

#. Go to *Point of Sale > Configuration > Point of Sale* and select one of
   them.
#. Set *Load Done Orders* on if you want to be able to load past orders in that
   PoS.
#. Change *Max Done Orders Quantity To Load* to your desired amount (10 by
   default). Please note that the more you load, the more it will take to load
   them in the session opening. You can also set it to 0 and you'll just be
   able to load them from the order list screen.
