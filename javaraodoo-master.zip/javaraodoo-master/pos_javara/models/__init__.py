from . import account
from . import pos_order
from . import res_partner_member
from . import pos_tender_type
from . import pos_order
from . import pos_discount_bank
