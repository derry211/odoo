from . import res_partner_member
from . import res_partner
from . import product_pricelist